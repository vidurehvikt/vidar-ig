# no.vidarure.fhir.lab-ig#0.1.0: Lab IG

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Konsultasjon](StructureDefinition-mal-encounter-konsultasjon.md)
* [Blodtrykkmåling](StructureDefinition-mal-observation-blodtrykk.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Lab IG](index.md)

### Examples

* [Konsultasjon-1 (Encounter)](Encounter-Konsultasjon-1.md)
* [Blodtrykk-1 (Observation)](Observation-Blodtrykk-1.md)
* [Pasient-1 (Patient)](Patient-Pasient-1.md)
